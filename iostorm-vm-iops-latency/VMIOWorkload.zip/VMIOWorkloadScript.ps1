#
# Copyright="?Microsoft Corporation. All rights reserved."
#

param (
    [Parameter(Mandatory)]
    [string]$ControllerVMName,
    [Parameter(Mandatory)]
    [string]$ControllerVMPrivateIP,
    [Parameter(Mandatory)]
    [string]$VMName,
    [Parameter(Mandatory)]
    [string]$VMAdminUserName,
    [Parameter(Mandatory)]
    [string]$VMAdminPassword,
    [Parameter(Mandatory)]
    [int32]$VMIoBlockSize,
    [Parameter(Mandatory)]
    [int32]$VMIoDuration,
    [Parameter(Mandatory)]
    [int32]$VMIoReadPercentage,
    [Parameter(Mandatory)]
    [int32]$VMIoMaxLatency,
    [int32]$FixedIops = 0,
    [string]$RunFixedIoLatencyTestAfterGoalSeek = "false",
    [int32]$DataDisks = 1,
    [bool]$StripeDisk = $true
)

# 1. Waits for a '$controllerReadySignalFile' (e.g. \\10.0.0.6\smbshare\iopresyncstart.txt) from a Controller VM then starts IO pre-sync 
# 2. Creates pre-sync file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate VM is up and waiting to start a workload
# 3. Waits for a '$ioWorkloadStartSignalFile' file (e.g. \\10.0.0.6\smbshare\ioworkloadstart-0) from a Controller VM (which indicates all VMs are ready and have created IOPreSync-VMx.log files) to signal all VMs to start IO workload with given 'QD' and 'THREAD' values inside the file
# 4. Copy IO result file '$ioResultFileName' (e.g. IOResult-VM0.log) in IO result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\ioresult-0)
# 5. If IO workload latency values is < given maxLatency, repeat step #3 with new values of 'QD' and 'THREAD', repeat step #4 and step #5
# 6. All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)

# Waits for a '$ioPreWorkloadSyncSucceedSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) (which indicates all VMs are ready and have created IOPreSync-VMx.log files) from a Controller VM then starts IO workload
# Copy IO result file '$ioResultFileName' (e.g. IOResult-VM0.log) in IO result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\)
# All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)
function VMIOWorkload {
    # Turn off private firewall off

    # RunFixedIoLatencyTestAfterGoalSeek is passed as a parameter from 
    # a scheduled task. It must be a string or int.
    if($RunFixedIoLatencyTestAfterGoalSeek -eq "true") {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $true
    } else {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $false
    }
    $ioStormMode = Get-IoStormMode -RunFixedIoLatencyTestAfterGoalSeek $RunFixedIoLatencyTestAfterGoalSeek -FixedIops $FixedIops

    netsh advfirewall set privateprofile state off
    netsh advfirewall set publicprofile state off

    # Local file storage location
    $localPath = "$env:SystemDrive"

    # Log file
    $logFileName = "VMWorkload-$VMName.log"
    $logFilePath = "$localPath\$logFileName"
    $restartRun = $false
    if(Test-Path $logFilePath -ErrorAction SilentlyContinue) {
        if($ioStormMode -eq "FixedIops") {
            "Restarting fixed IOPS run" | Out-File $logFilePath -Encoding ASCII -Append
            $restartRun = $true
        } else {
            Write-Host "Log file already exists. Skipping test execution."
            "Log file already exists. Skipping test execution." | Out-File $logFilePath -Encoding ASCII -Append
            return
        }
    }

    # Result SMB share
    $smbshare = "\\$ControllerVMPrivateIP\smbshare"

    # Create IO workload pre-sync directory
    $ioPreSyncShare = "$smbshare\iopresync"
    $ioPreSyncFileName = "IOPreSync-$VMName.log"

    # Sync signal to start IO pre-sync from controller vm
    $controllerReadySignalFile = "$smbshare\iopresyncstart.txt"

    # Start IO workload signal file from controller VM (also indicates pre IO workload sync succeed singal)
    $ioWorkloadStartSignalFile = "$smbshare\ioworkloadstart-"
    #$ioPreWorkloadSyncSucceedSignalFile = "$smbshare\iopresyncsucceed.txt"

    # Log directory
    $logShare = "$smbshare\logs"

    # Create IO result directory
    $ioResultShare = "$smbshare\ioresult"
    $ioResultFileName = "IOResult-$VMName.xml"

    $timeoutInSeconds = 7200
    # Setup connection to smb share of a controller VM, if net use fails retry until timeout
    $dtTime = Get-Date
    "Waiting for a share $smbshare to get online by a controller VM at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    $startTime = Get-Date
    $elapsedTime = $(Get-Date) - $startTime
    $syncTimeoutInSeconds = $timeoutInSeconds
    while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds) {
        net use $smbshare /user:$VMAdminUserName $VMAdminPassword
        if((Test-Path $smbshare) -eq $false) {
            Start-Sleep 3
        }
        else {
            $dtTime = Get-Date
            Write-Verbose "SMB share $smbshare is accessible"
            "Share $smbshare is made online by a controller VM at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
            break
        }
        $elapsedTime = $(Get-Date) - $startTime
    }

    # Wait for smb share on a controller VM
    $dtTime = Get-Date
    "Waiting for controller VM to get ready $controllerReadySignalFile at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    if((Test-Path $smbshare) -eq $true) {
        ##########################################
        ### WAIT TO START IO WORKLOAD PRE-SYNC ###
        ##########################################
        # Wait for all VMs to boot and come up before timeout
        $noOfRetries = $timeoutInSeconds/10
        while($noOfRetries -gt 0) {
            if((Test-Path $controllerReadySignalFile) -eq $true) {
                Write-Verbose "Wait to start pre-io synchronization is over"
                $noOfRetries = 0
            }
            Start-Sleep -Seconds 10
            if($noOfRetries -gt 0) {
                Write-Verbose "Waiting to start pre-io synchronization... $noOfRetries"
                $noOfRetries--
            }
        }
    }

    # Create pre-sync file
    $dtTime = Get-Date
    "Creating pre-sync file at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    "$VMName" | Out-File $localPath\$ioPreSyncFileName -Encoding ASCII -Append

    # Setup connection to smb share of a controller VM, if net use fails retry until timeout
    $startTime = Get-Date
    $elapsedTime = $(Get-Date) - $startTime
    # Wait until timeout
    $syncTimeoutInSeconds = $timeoutInSeconds/3
    while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds) {
        net use $smbshare /user:$VMAdminUserName $VMAdminPassword
        if((Test-Path $smbshare) -eq $false) {
            Start-Sleep 3
        }
        else {
            "SMB share $smbshare is accessible" | Out-File $logFilePath -Encoding ASCII -Append
            break
        }
        $elapsedTime = $(Get-Date) - $startTime
    }

    if((Test-Path $smbshare) -eq $true) {
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
        #############################
        ### DOWNLOAD DISKSPD TOOL ###
        #############################
        $diskspdSource = "https://raw.githubusercontent.com/zyxyoshine/AzureStack-QuickStart-Templates/iostormci/iostorm-vm-iops-latency/diskspd.exe"
        $diskspdFileName = [System.IO.Path]::GetFileName($diskspdSource)
        $diskspdDestination = "$localPath\$diskspdFileName"
        $workloadFileDrive = "F:"
        $workloadFilePath = $workloadFileDrive + "\iobw.tst"

        if($restartRun -eq $false) {
            
            $webClient = New-Object System.Net.WebClient
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
            $_date = Get-Date -Format hh:mmtt
            "Downloading diskspd IO load generating tool from $diskspdSource to $diskspdDestination at $_date" | Out-File $logFilePath -Encoding ASCII -Append
            $success = $false
            $downloadRetries = 20
            while($success -eq $false -and $downloadRetries -gt 0 ) {
                $success = $true
                $webClient.DownloadFile($diskspdSource, $diskspdDestination)
                $_date = Get-Date -Format hh:mmtt
                if((Test-Path $diskspdDestination) -eq $true) {
                    "Downloading diskspd IO load generating tool succeeded at $_date" | Out-File $logFilePath -Encoding ASCII -Append
                }
                else {
                    "WARN: Downloading diskspd IO load generating tool failed at $_date Retrying." | Out-File $logFilePath -Encoding ASCII -Append
                    $success = $false
                    $downloadRetries--
                    Start-Sleep -Seconds 30
                }
            }
            if($success -eq $false) {
                "ERROR: Downloading diskspd IO load generating tool failed at $_date No more retries, failing test." | Out-File $logFilePath -Encoding ASCII -Append
                return
            }
            # Create target file
            #unsure why we tried defaulting to this. Test would fail rather than no use the specified disk below
            #$workloadFileDrive = $env:SYSTEMDRIVE
        
            # Initialize disk
            InitializeAllDisks -NumDisks $DataDisks -StripeDisk $StripeDisk

            if ($StripeDisk)
            {
                $DataDisks = 1
            }

            $testFileList = BuildFileList -NumDisks $DataDisks -FileName "iobw.tst"
            "Test file list: $testFileList" | Out-File $logFilePath -Encoding ASCII -Append
                        
            $diskspdCmd = "$diskspdDestination -t2 -b512K -w90 -d900 -W0 -C0 -o8 -Sh -n -r -c768G $testFileList"
            "Starting diskspd workload $diskspdCmd" | Out-File $logFilePath -Encoding ASCII -Append
            Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
            cmd /c $diskspdCmd | Out-Null
        }

        # QD and Thread values
        $qd = -1
        $threads = -1
        $iteration = 0
        try {
            if($restartRun -eq $true) {
                #find highest iteration
                $startFilePath = "$ioWorkloadStartSignalFile*"
                $startFiles = Get-ChildItem $startFilePath
                $startNames = $startFiles.Name
                $allIterations = @()
                foreach($n in $startNames) {
                    $splitStr = $n.Split("-")
                    $iterStr = $splitStr[1]
                    $iterNum = [convert]::ToInt32($iterStr, 10)
                    $allIterations += $iterNum
                }
                $measure = $allIterations | Measure-Object -Maximum
                $iteration = $measure.Maximum 
            }
        } catch {
            "Failed to determine start iteration. Defaulting to 0. $_" | Out-File $logFilePath -Encoding ASCII -Append
        }
        "Starting with iteration $iteration" | Out-File $logFilePath -Encoding ASCII -Append
        # Stop IO workload execution when either no QD and THREADS value is provided by a controller VM or IO workload pre-synchronization fail
        $continueIoWorkloadExecution = $true

        ##########################################
        ### IO WORKLOAD PRE-SYNC + IO WORKLOAD ###
        ##########################################
        # Copy pre-sync file
        "Coyping pre-sync file $ioPreSyncFileName to $ioPreSyncShare" | Out-File $logFilePath -Encoding ASCII -Append
        Copy-Item $localPath\$ioPreSyncFileName $ioPreSyncShare\
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
        while($continueIoWorkloadExecution) {                       
            ############################
            ### IO WORKLOAD PRE-SYNC ###
            ############################
            $ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
            # Flag to indicate sync succeed
            $ioWorkloadSyncDidSucceed = $false
            # Wait for timeout
            $noOfRetries = $timeoutInSeconds/10
            while(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false)) {
                $fixedIopsPerDisk = 0

                # Check IO workload sync file
                if((Test-Path $ioWorkloadStartSignalFileIteration) -eq $true) {
                    $ioWorkloadSyncDidSucceed = $true
                    Write-Verbose "Start io-workload iteration $iteration synchronization succeeded."
                    "Start io-workload iteration $iteration synchronization succeeded (Sync signal $ioWorkloadStartSignalFileIteration is present)" | Out-File $logFilePath -Encoding ASCII -Append

                    # Get QD and THREADS values from a controller VM
                    $lines = Get-Content $ioWorkloadStartSignalFileIteration
                    foreach($line in $lines) {
                        if($line.Contains("QD") -eq $true) {
                            $qd = $line.Split(':')[1]
                        }
                        if($line.Contains("THREADS") -eq $true) {
                             $threads = $line.Split(':')[1]
                        }
                        if($line.Contains("FIXED") -eq $true) {
                            [int32]$fixedIopsPerDisk = [convert]::ToInt32($line.Split(':')[1], 10)
                        }
                    }
                    $noOfRetries = 0
                    # If Controller VM haven't provided QD or Thread value, stop IO workload execution
                    if(($qd -lt 0) -or ($threads -lt 0)) {
                        $continueIoWorkloadExecution = $false
                    }
                    break
                }

                # Wait for IO workload sync signal
                if(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false) -and $continueIoWorkloadExecution) {
                    Write-Verbose "Start io-workload iteration $iteration waiting... $noOfRetries"
                    if(($noOfRetries%6) -eq 0) {
                        "Start io-workload iteration $iteration waiting... $noOfRetries" | Out-File $logFilePath -Encoding ASCII -Append
                        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
                    }
                    $noOfRetries--
                    Start-Sleep -Seconds 10
                }
            }
            # Workload synchronization failed
            if($ioWorkloadSyncDidSucceed -eq $false) {
                $continueIoWorkloadExecution = $false
                Write-Verbose "Start io-workload iteration $iteration failed. IO workload execution is stopped."
                "Start io-workload iteration $iteration failed. IO workload execution is stopped." | Out-File $logFilePath -Encoding ASCII -Append
                Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
            }
            ###################
            ### IO WORKLOAD ###
            ###################
            elseif($continueIoWorkloadExecution) {
                # Io result share directory for current iteration
                $ioResultIterationShare = $ioResultShare + "\iteration-$iteration"

                # Validate parameters
                $VMIoWritePercentage = 100 - $VMIoReadPercentage
                if(($VMIoReadPercentage + $VMIoWritePercentage) -ne 100) {
                    Write-Verbose "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100."
                    "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100." | Out-File $logFilePath -Encoding ASCII -Append

                    # Update read/write % to valid default values
                    $VMIoReadPercentage = 70
                    $VMIoWritePercentage = 100 - $VMIoReadPercentage
                    Write-Verbose "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values"
                    "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values" | Out-File $logFilePath -Encoding ASCII -Append
                }

                # Run IO workload
                "Starting IO load generation with QD: $qd and THREADS: $threads" | Out-File $logFilePath -Encoding ASCII -Append

                # Refer to http://aka.ms/diskspd : 
                # t - threads, b - block size, w - write ratio, r - random, d - duration, W - warmup period, C - cooldown period, o - queue depth, Sh - disable software and hardware write caching, n - disable affinity, L - measure latency, D - capture IOPS higher-order stats in intervals of ms
                if($fixedIopsPerDisk -eq 0 -or $FixedIops -eq 0) {
                    $diskspdCmd = "$diskspdDestination -t$threads -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d$VMIoDuration -W60 -C60 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                } elseif($fixedIopsPerDisk -ne 0 -and $RunFixedIoLatencyTestAfterGoalSeek -eq $true) {
                    $bytesPerMs = ($VMIoBlockSize * $fixedIopsPerDisk) / 1000 / ($threads * $DataDisks)
                    if($bytesPerMs -lt 1) {
                        $bytesPerMs = 1
                    }
                    "Using fixed IO -g$bytesPerMs" | Out-File $logFilePath -Encoding ASCII -Append
                    $diskspdCmd = "$diskspdDestination -t$threads -g$bytesPerMs -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d120 -W60 -C60 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                } else {
                    $bytesPerMs = ($VMIoBlockSize * $FixedIops) / 1000 / ($threads * $DataDisks)
                    if($bytesPerMs -lt 1) {
                        $bytesPerMs = 1
                    }
                    "Using fixed IO -g$bytesPerMs" | Out-File $logFilePath -Encoding ASCII -Append
                    $diskspdCmd = "$diskspdDestination -t$threads -g$bytesPerMs -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d$VMIoDuration -W60 -C60 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                }

                "IO workload: $diskspdCmd" | Out-File $logFilePath -Encoding ASCII -Append
                Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
                cmd /c $diskspdCmd
                "IO workload has finished" | Out-File $logFilePath -Encoding ASCII -Append

                # Update Machine Name to add right VM index as all VMs uses same name (e.g. VMBootVM => VMBootVM0, VMBootVM1, VMBootVM2...)
                (Get-Content $localPath\$ioResultFileName) | Foreach-Object {$_ -replace "<ComputerName>$env:COMPUTERNAME</ComputerName>", "<ComputerName>$VMName</ComputerName>"} | Set-Content $localPath\$ioResultFileName

                # Copy result file
                Copy-LogFiles -Src $localPath\$ioResultFileName -Dest $ioResultIterationShare\ -LogFilePath $logFilePath               
            }
            else {
                Write-Verbose "Stopping IO workload at iteration $iteration"
                "Stopping IO workload at iteration $iteration" | Out-File $logFilePath -Encoding ASCII -Append
            }
            $iteration += 1
        }

        # Copy log file
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath

    }
    else {
        $dtTime = Get-Date
        Write-Verbose "SMB Share $smbshare is not accessible at $dtTime"
        "SMB share $smbshare is not accessible at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
        "Cannot run IO test as SMB Share $smbshare is not accessible at $dtTime" | Out-File $localPath\$ioResultFileName -Encoding ASCII -Append
    }
    "Script execution ended" | Out-File $logFilePath -Encoding ASCII -Append
}

function WaitForDisk
{
    param(
    [UInt32]$DiskNumber,
    [UInt64]$RetryIntervalSec = 10,
    [UInt32]$RetryCount = 60
    )
    $diskFound = $false
    Write-Verbose -Message "Checking for disk '$($DiskNumber)' ..."

    for ($count = 0; $count -lt $RetryCount; $count++)
    {
        $disk = Get-Disk -Number $DiskNumber -ErrorAction SilentlyContinue
        if (!!$disk)
        {
            Write-Verbose -Message "Found disk '$($disk.FriendlyName)'."
            $diskFound = $true
            break
        }
        else
        {
            Write-Verbose -Message "Disk '$($DiskNumber)' NOT found."
            Write-Verbose -Message "Retrying in $RetryIntervalSec seconds ..."
            Start-Sleep -Seconds $RetryIntervalSec
        }
    }

    if (!$diskFound)
    {
        throw "Disk '$($DiskNumber)' NOT found after $RetryCount attempts."
    }
    return $diskFound
}

function InitializeDisk
{
    param(
    [UInt32] $DiskNumber,
    [String] $DriveLetter
    )
    
    $disk = Get-Disk -Number $DiskNumber
    
    if($disk -eq $null){
        return $false
    }

    if ($disk.PartitionStyle -ne "RAW") {
        "Disk number '$($DiskNumber)' has already been initialized." | Out-File $logFilePath -Encoding ASCII -Append                    
        return $true
    }

    if ($disk.IsOffline -eq $true)
    {
        "Setting disk Online" | Out-File $logFilePath -Encoding ASCII -Append                    
        $disk | Set-Disk -IsOffline $false
    }
    
    if ($disk.IsReadOnly -eq $true)
    {
        "Setting disk to not ReadOnly" | Out-File $logFilePath -Encoding ASCII -Append                    
        $disk | Set-Disk -IsReadOnly $false
    }
    
    if ($disk.PartitionStyle -eq "RAW")
    {
        "Initializing disk number $($DiskNumber)..." | Out-File $logFilePath -Encoding ASCII -Append                    

        $disk | Initialize-Disk -PartitionStyle GPT -PassThru
        if ($DriveLetter)
        {
            $partition = $disk | New-Partition -DriveLetter $DriveLetter -UseMaximumSize
        }
        else
        {
            $partition = $disk | New-Partition -AssignDriveLetter -UseMaximumSize
        }

        # Sometimes the disk will still be read-only after the call to New-Partition returns.
        Start-Sleep -Seconds 5

        if($partition -ne $null) {
            $volume = $partition | Format-Volume -FileSystem NTFS -Confirm:$false

            "Successfully initialized disk number '$($DiskNumber)'." | Out-File $logFilePath -Encoding ASCII -Append                    
        }
        else {
            "Failed to initialize disk num '$($DiskNumber)'." | Out-File $logFilePath -Encoding ASCII -Append                    
        }
    }
    
    if (($disk | Get-Partition | Where-Object { $_.DriveLetter -ne "`0" } | Select-Object -ExpandProperty DriveLetter) -ne $DriveLetter)
    {
        "Changing drive letter to $DriveLetter" | Out-File $logFilePath -Encoding ASCII -Append                    
        Set-Partition -DiskNumber $disknumber -PartitionNumber (Get-Partition -Disk $disk | Where-Object { $_.DriveLetter -ne "`0" } | Select-Object -ExpandProperty PartitionNumber) -NewDriveLetter $driveletter
    }

    return true
}

function InitializeDiskPool
{
    param(
        [UInt32] $DiskPoolSize,
        [String] $DriveLetter
    )

    $physicalDisk = Get-PhysicalDisk | where {$_.CanPool -eq $true}

    if ($physicalDisk.Count -eq 0) {
        return $false
    }

    if ($physicalDisk.Count -ne $DiskPoolSize) {
        throw "Unexpected number of data disk found. Expected value: $DiskPoolSize. Actual value: $($physicalDisk.Count)."
    }

    $poolName = "TestDiskPool"
    $vdName = "TestVD"
    $volName = "TestVolume"
    $storage = Get-StorageSubSystem
    New-StoragePool -FriendlyName $poolName -PhysicalDisks $physicalDisk -StorageSubSystemName $storage.Name
    New-VirtualDisk -FriendlyName $vdName `
                    -ResiliencySettingName Simple `
                    -NumberOfColumns $physicalDisk.Count `
                    -UseMaximumSize -Interleave 65536 -StoragePoolFriendlyName $poolName
    $vdiskNumber = (Get-Disk -FriendlyName $vdName).Number
    Initialize-Disk -FriendlyName $vdName -PartitionStyle GPT -PassThru
    New-Partition -UseMaximumSize -DiskNumber $vdiskNumber -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $volName -AllocationUnitSize 65536 -Force -Confirm:$false

    return $true
}

function Copy-LogFiles
{
    param(
    [String] $Src,
    [String] $Dest,
    [string] $LogFilePath
    )
    $success = $false
    $iteration = 0
    while(!$success) {        
        try {
            Copy-Item $Src $Dest -Force
            $success = $true
        } catch {
            $success = $false
            $d = Get-Date
            "$d Failed to copy logs for $iteration. Src: $Src Dest: $Dest Retrying. $_" | Out-File $LogFilePath -Encoding ASCII -Append
            $iteration++
            Start-Sleep -Seconds 10
        }
    }
}
function InitializeAllDisks
{
    param(
        [int32]$NumDisks,
        [bool] $StripeDisk
    )

    $driveLetters = "FGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
    $diskNumber = 1

    if ((-not $StripeDisk) -or ($NumDisks -eq 1))
    {
        for ($i = 0; $i -lt $NumDisks; $i++)
        {
            ++$diskNumber

            if(WaitForDisk -DiskNumber $diskNumber) {
                [string]$driveLetter = $driveLetters[$i]

                if(InitializeDisk -DiskNumber $diskNumber -DriveLetter $driveLetter) {
                    "Initializing disk $diskNumber at $driveLetter)" | Out-File $logFilePath -Encoding ASCII -Append
                }
            }
        }
    }
    else
    {
        [string]$driveLetter = $driveLetters[0]
        $poolDisk = Get-Disk -Number $($diskNumber + $NumDisks + 1) -ErrorAction SilentlyContinue

        if ($poolDisk)
        {
            "Found pool disk '$($poolDisk.FriendlyName)'." | Out-File $logFilePath -Encoding ASCII -Append
        }
        else
        {
            for($i = 0; $i -lt $NumDisks; $i++) {
                ++$diskNumber
                WaitForDisk -DiskNumber $diskNumber
            }

            if(InitializeDiskPool -DiskPoolSize $NumDisks -DriveLetter $driveLetter) {
                "Initializing disk $(++$diskNumber) at $driveLetter with a pool of $NumDisks disks" | Out-File $logFilePath -Encoding ASCII -Append
            }
        }
    }
}

function BuildFileList
{
    param(
    [int32]$NumDisks,
    [string]$FileName
    )
    $driveLetters = "FGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
    $str = ""
    for($i = 0; $i -lt $NumDisks; $i++) {        
        $str += "$($driveLetters[$i]):\$FileName "
    }
    return $str
}

function Get-IoStormMode {
    param (
        [bool]$RunFixedIoLatencyTestAfterGoalSeek,
        [int32]$FixedIops
    )
    if($RunFixedIoLatencyTestAfterGoalSeek -eq $true -and $FixedIops -ne 0) {
        $ioStormInitialMode = "GoalSeek"
        $ioStormMode = "GoalSeekFixedIops"
    } elseif($RunFixedIoLatencyTestAfterGoalSeek -eq $false -and $FixedIops -ne 0) {
        $ioStormMode = "FixedIops"
    } else {
        $ioStormMode = "GoalSeek"
    }
    return $ioStormMode
}

VMIOWorkload

# SIG # Begin signature block
# MIIjewYJKoZIhvcNAQcCoIIjbDCCI2gCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB/1C9HkydmDu/O
# 7NQ33DN8NlICebwyyer8KdHD4U1T2KCCDXYwggX0MIID3KADAgECAhMzAAABhk0h
# daDZB74sAAAAAAGGMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ2WhcNMjEwMzAzMTgzOTQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC49eyyaaieg3Xb7ew+/hA34gqzRuReb9svBF6N3+iLD5A0iMddtunnmbFVQ+lN
# Wphf/xOGef5vXMMMk744txo/kT6CKq0GzV+IhAqDytjH3UgGhLBNZ/UWuQPgrnhw
# afQ3ZclsXo1lto4pyps4+X3RyQfnxCwqtjRxjCQ+AwIzk0vSVFnId6AwbB73w2lJ
# +MC+E6nVmyvikp7DT2swTF05JkfMUtzDosktz/pvvMWY1IUOZ71XqWUXcwfzWDJ+
# 96WxBH6LpDQ1fCQ3POA3jCBu3mMiB1kSsMihH+eq1EzD0Es7iIT1MlKERPQmC+xl
# K+9pPAw6j+rP2guYfKrMFr39AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhTFTFHuCaUCdTgZXja/OAQ9xOm4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ1ODM4NDAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAEDkLXWKDtJ8rLh3d7XP
# 1xU1s6Gt0jDqeHoIpTvnsREt9MsKriVGKdVVGSJow1Lz9+9bINmPZo7ZdMhNhWGQ
# QnEF7z/3czh0MLO0z48cxCrjLch0P2sxvtcaT57LBmEy+tbhlUB6iz72KWavxuhP
# 5zxKEChtLp8gHkp5/1YTPlvRYFrZr/iup2jzc/Oo5N4/q+yhOsRT3KJu62ekQUUP
# sPU2bWsaF/hUPW/L2O1Fecf+6OOJLT2bHaAzr+EBAn0KAUiwdM+AUvasG9kHLX+I
# XXlEZvfsXGzzxFlWzNbpM99umWWMQPTGZPpSCTDDs/1Ci0Br2/oXcgayYLaZCWsj
# 1m/a0V8OHZGbppP1RrBeLQKfATjtAl0xrhMr4kgfvJ6ntChg9dxy4DiGWnsj//Qy
# wUs1UxVchRR7eFaP3M8/BV0eeMotXwTNIwzSd3uAzAI+NSrN5pVlQeC0XXTueeDu
# xDch3S5UUdDOvdlOdlRAa+85Si6HmEUgx3j0YYSC1RWBdEhwsAdH6nXtXEshAAxf
# 8PWh2wCsczMe/F4vTg4cmDsBTZwwrHqL5krX++s61sLWA67Yn4Db6rXV9Imcf5UM
# Cq09wJj5H93KH9qc1yCiJzDCtbtgyHYXAkSHQNpoj7tDX6ko9gE8vXqZIGj82mwD
# TAY9ofRH0RSMLJqpgLrBPCKNMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCFVswghVXAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAGGTSF1oNkHviwAAAAAAYYwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBSFZRabzzP1/XYsihfge7lK
# asgcGQsMOXgvMt20fVBrMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAmWGC470YDyNIs56lRMDH962eRhwkmD7yV09UBTyoPBhFR6mfAAsDqjp5
# yL6bf2V9lDhM3bALJbOqi18nkO7HP3zrIL2mReCoaDB79CTDFLFCKznpuUdLQ6Yp
# iRLT+NleZmL1HCmDwpXQuiHgV4r0BHJkPq+LVYsGL8RQvTwAYqC8B+bfMUTKybtM
# nW0k5CNVil/I1Y5qARIXoa7UJKOrS2vo0K99NbyKtIBVWv3BLdSzq3QiQyta4WEZ
# 24aWXbCXx0WylIQRcKK7kb4W/ahTH5M1UE3w6lvoPQBgYimphkif3qZ1bO2iXqj0
# wxD++WEMe6leYRw6r6yVrdqZz5Pg3aGCEuUwghLhBgorBgEEAYI3AwMBMYIS0TCC
# Es0GCSqGSIb3DQEHAqCCEr4wghK6AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCdxAUCiygCaNN4G1z30nDdflCH7FRdIpAEXXPN30XyQQIGYAYaoec7
# GBMyMDIxMDEyNjA1MDQxMi41NDZaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUy
# N0MtNTkyRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# DjwwggTxMIID2aADAgECAhMzAAABR52P8ebeMYNZAAAAAAFHMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIwMTExMjE4MjU1
# NVoXDTIyMDIxMTE4MjU1NVowgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEF
# AAOCAQ8AMIIBCgKCAQEArQUDTOl99ihZPwSfGGqa38xLei49+BvlS484HxIDhklX
# dTLu5wqYStCuKMj68yLYDUYweIFIiquhs4MXQx4GT4ExL5ue87GrHMhq8m1pH91V
# a/G6n9jyIBr8CgzRIFXMoLBG7lsF8/S4ujOwDqA+EwfH5eAE5vi+2+PpWA1DCWDC
# 86YiczO+OWtFx4q4lGjqWFn5MDvR8+rn/pNh6u8hsoLh/J2jyzJ2H5mCLdj1wMFl
# bxuDA+GG41wVWdeLnoe2JamUzLmt5/ZE9QmQ7B78/qOfJ7KGpl0cERTm+yw41Vfv
# nGSGSztvbrIiNB+/bW930r4fbVO0AuwoqzQgWGoDSQIDAQABo4IBGzCCARcwHQYD
# VR0OBBYEFLT43G/eZKGGVxsvQz8TePXUgrC6MB8GA1UdIwQYMBaAFNVjOlyKMZDz
# Q3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAx
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0
# MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEL
# BQADggEBAFDEDso1fnmtpBLV6g9HDnw9mdjxVCMuZC5BlOd0QxnH4ZcyEfUJU4GS
# 6kxIYCy7gksuo3Jmvpz4O3uV4NaKgmXGSUcLUT80tRevzOmEd+R926zdJmlZz65q
# 0PdZJH7Dag07blg4gCAX5DRIAqUGQm+DldxzLuS/Hmc4OXVGie1xPiwbqYSUixSb
# Wm8WLeH5AkMZ0w9s+dGN9mbl4jZhRYmu6lavt2HN5pltNvvylh/D9Rz4qGyRvHKx
# mIEhJMbZFFxnaLrcBllvPCkfUUXDP+Bii6rdjkPAFhEG+7IYDPKcTb7t9E8Xo0QK
# WuFgHzgHo0xuPiswZuu141WdiJVwD5IwggZxMIIEWaADAgECAgphCYEqAAAAAAAC
# MA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRo
# b3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vh
# wna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs
# 1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WET
# bijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wG
# Pmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf0
# 3GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGC
# NxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQB
# gjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BL
# SS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBh
# AGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG
# 9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkw
# s8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/
# XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO
# 9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHO
# mWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU
# 9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6
# YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdl
# R3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rI
# DVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkq
# mqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN
# +w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLO
# MIICNwIBATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEm
# MCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTVBNi1FMjdDLTU5MkUxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAKun
# wbRBDaHDQEjKi9N8xiUtMGXdoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDjudONMCIYDzIwMjEwMTI2MDczMjI5
# WhgPMjAyMTAxMjcwNzMyMjlaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOO5040C
# AQAwCgIBAAICJngCAf8wBwIBAAICEcswCgIFAOO7JQ0CAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQUFAAOBgQC7Vyb2SE+LhNMb1JektfGXtSe1BIWOaKCQVveGYJZ+xzFQ
# dKN+TII4QKIB8VvJ6+w+ODY6TCxaGQ7NlDL12zU02JcEap//hF0SDbJdxBPueLT6
# Q7gsGzH93V0AEYuELLvgDDHGbc7iSM7SqOi7z7ZnNvKfJwcnvlT0Dwm0bIWkaDGC
# Aw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# R52P8ebeMYNZAAAAAAFHMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMx
# DQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIJJtMtASlJicSMTQjPEsydck
# tRQdAWnVAdVQLTFXlzoyMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQge9s8
# EgOUz7oGyImTv9h9Ya4rAFSLcMw7HG9FqooY6YUwgZgwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAUedj/Hm3jGDWQAAAAABRzAiBCAC4XWk
# qFL9LwNrJKSZeAJbfProFSu9FXkj4Rcfv/bqYzANBgkqhkiG9w0BAQsFAASCAQAB
# QROeMU+HnNDf5TECYWtvDJgE/QXU9lsIJJPv8+uXPzR7xBtg0i5Dz3TMaaA+cox8
# zpomRRKsYI1r99YlDWsHskMc9z1wRv3mnul6xAvn9nYnXqAQ4Pagtetx067DPs/S
# CwJ8C28xAAcuRvLup4nPNi3InU+8NVynymOjOQGb6BrCBttmjpblGVWuOZ20NDO4
# mwV/eRYJcHtEFJll1Bln/1TLsduzWlVeMFwU2iQ+0MSTMDbFMQRVeVFPOSqJnxm8
# TgYJLyLaHXGrJekEq2tBgaCfUgvGsNAFQaGcfK+2T+FIEx8js1a3dOh59KK4cvXS
# BPEL3vymCJAAm+LItT7M
# SIG # End signature block
